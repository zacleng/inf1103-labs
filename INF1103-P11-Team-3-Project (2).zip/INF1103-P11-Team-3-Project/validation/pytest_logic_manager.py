

import os
import sys

# Add the parent directory of 'validation' to the search path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
import copy
from logic_manager import (
    adapt_analysis, 
    _calculate_base_score, 
    _score_level, 
    _apply_rules, 
    calculate_risk_level
)

# INPUT: None (Pytest fixture)
# PROCESS: Creates a valid risk dictionary matching the schema for baseline testing.
# OUTPUT: Returns a deepcopy-safe dictionary.
@pytest.fixture
def valid_risk_item():
    return {
        "category": "Financial Risks",
        "flag": "Upfront payment",
        "cite": "Pay a $150 registration fee.",
        "reasoning": "Demands money upfront."
    }

# INPUT: valid_risk_item (Dictionary fixture)
# PROCESS: Tests that a valid flag correctly maps to its internal boolean factor.
# OUTPUT: None (Test passes if the internal factor is True and no unresolved evidence is logged)
def test_adapt_analysis_successful_mapping(valid_risk_item):
    adapted = adapt_analysis([valid_risk_item])
    
    # Ensure the internal factor was triggered
    assert adapted["risk_factors"]["financial_risks"]["upfront_payment"] is True
    # Ensure it was not flagged as unresolved
    assert len(adapted["unresolved_evidence"]) == 0

# INPUT: valid_risk_item (Dictionary fixture)
# PROCESS: Mutates the flag to an unrecognized string to test the fallback handler for unknown data.
# OUTPUT: None (Test passes if the item is logged as 'unknown_evidence')
def test_adapt_analysis_unknown_flag(valid_risk_item):
    item = copy.deepcopy(valid_risk_item)
    item["flag"] = "Space laser request"
    
    adapted = adapt_analysis([item])
    
    assert len(adapted["unresolved_evidence"]) == 1
    assert adapted["unresolved_evidence"][0]["reason"] == "unknown_evidence"

# INPUT: valid_risk_item (Dictionary fixture)
# PROCESS: Modifies the category to one that does not own the provided flag.
# OUTPUT: None (Test passes if the item is logged as 'category_mismatch')
def test_adapt_analysis_category_mismatch(valid_risk_item):
    item = copy.deepcopy(valid_risk_item)
    item["category"] = "Job Offer Risks"  # Mismatch: Upfront payment is a Financial Risk
    
    adapted = adapt_analysis([item])
    
    assert len(adapted["unresolved_evidence"]) == 1
    assert adapted["unresolved_evidence"][0]["reason"] == "category_mismatch"

# INPUT: None
# PROCESS: Tests boundary conditions and invalid types for the score classification function.
# OUTPUT: None (Test passes if ValueErrors are caught and valid scores return correct strings)
def test_score_level_bounds():
    # 1. Test valid threshold bounds (Low < 20, Medium >= 20, High >= 40, Critical >= 70)
    assert _score_level(0) == "low"
    assert _score_level(20) == "medium"
    assert _score_level(40) == "high"
    assert _score_level(70) == "critical"
    
    # 2. Test negative integer rejection
    with pytest.raises(ValueError, match="Score must be a non-negative integer."):
        _score_level(-5)
        
    # 3. Test non-integer (float) rejection
    with pytest.raises(ValueError, match="Score must be a non-negative integer."):
        _score_level(25.5)

# INPUT: None
# PROCESS: Creates mock flattened flag dictionaries to verify the multi-condition domain rules trigger correctly.
# OUTPUT: None (Test passes if the highest severity rule is applied)
def test_apply_rules_overrides():
    # 1. Test phishing_trap rule trigger (Requires banking info AND unverifiable employer)
    flags = {
        "banking_information_request": True,
        "unverifiable_employer": True
    }
    assert _apply_rules(flags) == "critical"
    
    # 2. Test partial rule match (Should return None if all clauses aren't met)
    partial_flags = {
        "banking_information_request": True,
        "upfront_payment": False
    }
    assert _apply_rules(partial_flags) is None

# INPUT: valid_risk_item (Dictionary fixture)
# PROCESS: Tests the full integration pipeline from raw list to final string severity level.
# OUTPUT: None (Test passes if the output is a valid lowercase severity string)
def test_calculate_risk_level_integration(valid_risk_item):
    # 1. Test with a standard valid risk (Upfront payment base score is 40 -> 'high')
    level = calculate_risk_level([valid_risk_item])
    assert level == "high"
    
    # 2. Test with an empty list to ensure baseline risk works
    empty_level = calculate_risk_level([])
    assert empty_level == "low"



# INPUT: None
# PROCESS: Tests that the base score correctly sums the assigned weights of multiple active flags, while ignoring inactive (False) flags.
# OUTPUT: None (Test passes if the summation equals exactly 60)
def test_calculate_base_score_summation():
    # Based on SSOT: upfront_payment (40) + guaranteed_income (20) = 60
    flags = {
        "upfront_payment": True,
        "guaranteed_income": True,
        "unrealistic_salary": False  # Should be ignored
    }
    assert _calculate_base_score(flags) == 60

# INPUT: None
# PROCESS: Tests the max() constraint to ensure rule overrides only upgrade severity, never downgrade it.
# OUTPUT: None (Test passes if the highest level is preserved)
def test_rule_precedence_and_overrides():
    # Scenario A: Base score is Low (0), but rule triggers 'critical'
    # Phishing trap: banking + unverifiable
    critical_risk_item = {
        "category": "Personal Information Risks",
        "flag": "Banking information requests",
        "cite": "Send bank details",
        "reasoning": "Test"
    }
    critical_risk_item2 = {
        "category": "Company Legitimacy Risks",
        "flag": "Unverifiable employer details",
        "cite": "No company name",
        "reasoning": "Test"
    }
    
    # Base score is 40 + 15 = 55 ("high"), but the phishing rule mandates "critical".
    assert calculate_risk_level([critical_risk_item, critical_risk_item2]) == "critical"

# INPUT: None
# PROCESS: Tests how the logic manager handles a massive accumulation of minor flags to ensure the cap behavior functions.
# OUTPUT: None (Test passes if it caps safely at 'critical')
def test_calculate_risk_level_massive_score():
    # Create multiple minor/medium risks that sum well over 70
    risks = [
        {"category": "Job Offer Risks", "flag": "Unrealistic salary", "cite": "1", "reasoning": "1"}, # 20
        {"category": "Job Offer Risks", "flag": "Guaranteed income", "cite": "2", "reasoning": "2"}, # 20
        {"category": "Job Offer Risks", "flag": "No experience required despite high pay", "cite": "3", "reasoning": "3"}, # 20
        {"category": "Company Legitimacy Risks", "flag": "Limited company information", "cite": "4", "reasoning": "4"}, # 10
        {"category": "Company Legitimacy Risks", "flag": "Suspicious contact information", "cite": "5", "reasoning": "5"} # 15
    ]
    # Sum is 85. Threshold for critical is >= 70.
    assert calculate_risk_level(risks) == "critical"