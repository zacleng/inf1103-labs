import pytest
import copy
import os
import sys

# Add the parent directory of 'validation' to the search path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))



from validation_manager import validate_entry, validate_reports

# INPUT: None (Pytest fixture)
# PROCESS: Creates a perfectly valid, minimal job entry dictionary to serve as a clean baseline for each test.
# OUTPUT: Returns the base dictionary.
@pytest.fixture
def valid_base_entry():
    # Return a deepcopy-safe dictionary matching the exact valid schema
    return {
        "entry_id": 1001,
        "job_post_id": 501,
        "platform": "telegram",
        "raw_job_posting": "Sample valid text",
        "manual_entry": False,
        "entry_created": "2026-10-10T14:30:00+08:00",
        "job_type": "full_time",
        "experience_level": None,
        "tasks": ["Do work"],
        "date_posted": "2026-10-09T10:00:00+08:00",
        "benefits": [],
        "location": {"type": "remote", "address": None},
        "contact": {"name": "Recruiter", "methods": [{"type": "email", "identifier": "test@example.com"}]},
        "license": None,
        "salary_scheme": {"monthly": {"rate": 5000.0, "negotiable": False}},
        "detected_risks": [],
        "risk_level": "low"
    }



# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Passes the pristine base entry into the validator to ensure it doesn't raise any errors.
# OUTPUT: None (Test passes if no exception is raised)
def test_valid_entry_passes(valid_base_entry):
    # Process the base entry
    result = validate_entry(valid_base_entry)
    # Ensure the returned result retains the correct ID
    assert result["entry_id"] == 1001

# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Mutates the base entry by removing a required field and adding an unrecognized field to test structural validation.
# OUTPUT: None (Test passes if ValueError is raised with specific error messages)
def test_structural_integrity(valid_base_entry):
    # Deepcopy to prevent mutating the fixture globally
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test missing required field
    del entry["platform"]
    with pytest.raises(ValueError, match="Missing required field"):
        validate_entry(entry)
        
    # 2. Test unexpected extra field
    entry["platform"] = "telegram"  # Restore missing field
    entry["spaceship_model"] = "Apollo" # Inject bad field
    with pytest.raises(ValueError, match="Unexpected field"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Mutates simple fields (booleans, enums, ISO datetimes) to test simple data type and constraint validations.
# OUTPUT: None (Test passes if ValueErrors are caught)
def test_simple_datatypes_and_enums(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test invalid boolean
    entry["manual_entry"] = "False"  # String instead of bool
    with pytest.raises(ValueError, match="manual_entry must be a boolean"):
        validate_entry(entry)
        
    # 2. Test invalid enum
    entry["manual_entry"] = False
    entry["job_type"] = "spaceship_captain"
    with pytest.raises(ValueError, match="job_type must be one of:"):
        validate_entry(entry)
        
    # 3. Test malformed ISO 8601 Date
    entry["job_type"] = "full_time"
    entry["entry_created"] = "10-10-2026 2:30 PM"
    with pytest.raises(ValueError, match="must be a valid ISO 8601"):
        validate_entry(entry)
        
    # 4. Test missing timezone in Date
    entry["entry_created"] = "2026-10-10T14:30:00" # Missing +08:00 or Z
    with pytest.raises(ValueError, match="must include a timezone"):
        validate_entry(entry)



# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests complex nested dependencies in the location field (e.g., onsite requiring an address).
# OUTPUT: None (Test passes if validation enforces conditional rules)
def test_location_complex_rules(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test onsite missing an address (Complex conditional dependency)
    entry["location"] = {"type": "onsite", "address": None}
    with pytest.raises(ValueError, match="location.address is required when location.type is 'onsite'"):
        validate_entry(entry)
        
    # 2. Test remote allowing a null address (Should Pass)
    entry["location"] = {"type": "remote", "address": None}
    validate_entry(entry) # Should not raise


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests the regex constraints applied to nested contact identifiers.
# OUTPUT: None (Test passes if regex failures trigger ValueErrors)
def test_contact_identifier_regexes(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test bad email format
    entry["contact"]["methods"] = [{"type": "email", "identifier": "not-an-email"}]
    with pytest.raises(ValueError, match="must look like a valid email address"):
        validate_entry(entry)
        
    # 2. Test bad phone format (letters injected)
    entry["contact"]["methods"] = [{"type": "phone", "identifier": "+65 8123 ABCD"}]
    with pytest.raises(ValueError, match="must look like a phone number"):
        validate_entry(entry)
        
    # 3. Test duplicate contact methods
    entry["contact"]["methods"] = [
        {"type": "whatsapp", "identifier": "+6591234567"},
        {"type": "whatsapp", "identifier": "+6591234567"}
    ]
    with pytest.raises(ValueError, match="contains duplicate method"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Mutates the salary scheme to test math constraints (negative numbers, finite numbers) and specific dictionary structures.
# OUTPUT: None (Test passes if incorrect schemas are blocked)
def test_salary_scheme_complex_rules(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test negative salary rate
    entry["salary_scheme"] = {"monthly": {"rate": -50.0, "negotiable": False}}
    with pytest.raises(ValueError, match="rate must be a finite number >= 0"):
        validate_entry(entry)
        
    # 2. Test missing required 'type' field strictly for 'ad_hoc' scheme
    entry["salary_scheme"] = {"ad_hoc": {"rate": 500.0, "negotiable": True}}
    with pytest.raises(ValueError, match="must contain exactly: negotiable, rate, type"):
        validate_entry(entry)



# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Verifies that risk flags strictly belong to their assigned parent categories.
# OUTPUT: None (Test passes if category-flag mismatch is rejected)
def test_detected_risks_category_binding(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # Inject a known flag ("Upfront payment") into the WRONG category ("Job Offer Risks")
    entry["detected_risks"] = [
        {
            "category": "Job Offer Risks", # Mismatch! Upfront payment belongs to Financial Risks
            "flag": "Upfront payment",
            "cite": "Text",
            "reasoning": "Text"
        }
    ]
    with pytest.raises(ValueError, match="is not valid for category"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Deliberately injects the exact same risk category and flag twice into the detected_risks list to trigger the duplicate risk check.
# OUTPUT: None (Test passes if ValueError is caught)
def test_duplicate_detected_risks(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # Create a single valid risk object
    risk_item = {
        "category": "Social Engineering Risks",
        "flag": "Excessive urgency",
        "cite": "Apply now!",
        "reasoning": "High pressure."
    }
    
    # Inject the exact same risk twice into the list
    entry["detected_risks"] = [risk_item, risk_item]
    
    # Expect the validator to catch the duplicate pair
    with pytest.raises(ValueError, match="contains duplicate category/flag"):
        validate_entry(entry)



# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Creates a mock database (a list of reports) containing two entries with the exact same entry_id to test the array-level validation.
# OUTPUT: None (Test passes if ValueError is caught)
def test_duplicate_entry_ids_in_database(valid_base_entry):
    # Create two identical entries (meaning they share the same entry_id: 1001)
    entry_one = copy.deepcopy(valid_base_entry)
    entry_two = copy.deepcopy(valid_base_entry)
    
    # Place them both into a list representing the JSON database
    mock_database = [entry_one, entry_two]
    
    # validate_reports is responsible for checking uniqueness across the whole array
    with pytest.raises(ValueError, match="ID is missing / a duplicate"):
        validate_reports(mock_database)

# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests the boundary conditions of integer fields like entry_id and job_post_id to ensure they reject 0, negatives, and invalid types[cite: 2].
# OUTPUT: None (Test passes if ValueError is caught)
def test_integer_bounds_and_identifiers(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test entry_id below minimum bound (must be >= 1)[cite: 2]
    entry["entry_id"] = 0
    with pytest.raises(ValueError, match="entry_id must be >= 1"):
        validate_entry(entry)
        
    # 2. Test job_post_id with invalid type (string instead of integer)[cite: 2]
    entry["entry_id"] = 1001
    entry["job_post_id"] = "501"
    with pytest.raises(ValueError, match="job_post_id must be an integer"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests string handling to ensure whitespace-only strings and empty lists are rejected across required text fields[cite: 2].
# OUTPUT: None (Test passes if ValueError is caught)
def test_empty_strings_and_lists(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test whitespace-only string for raw_job_posting[cite: 2]
    entry["raw_job_posting"] = "   \n  "
    with pytest.raises(ValueError, match="raw_job_posting must be a non-empty string"):
        validate_entry(entry)
        
    # 2. Test empty list for tasks[cite: 2]
    entry["raw_job_posting"] = "Valid text"
    entry["tasks"] = []
    with pytest.raises(ValueError, match="tasks must contain at least one item"):
        validate_entry(entry)
        
    # 3. Test empty string inside the tasks list[cite: 2]
    entry["tasks"] = ["Valid task", ""]
    with pytest.raises(ValueError, match="tasks\\[1\\] must be a non-empty string"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests license length, character restrictions, uppercase requirements,
#          and nullability.
# OUTPUT: None (Test passes if invalid formats are rejected and valid ones pass)
def test_license_regex(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)

    error_message = (
        "license must be null or contain exactly 7 uppercase alphanumeric characters"
    )
    entry["license"] = ""
    with pytest.raises(ValueError, match="license must be a non-empty string"):
                validate_entry(entry)

    # 1. Invalid length: fewer or more than 7 characters
    for license_value in ["123456", "12345678"]:
        entry["license"] = license_value
        with pytest.raises(ValueError, match=error_message):
            validate_entry(entry)

    # 2. Invalid characters: special characters and punctuation
    for license_value in ["12345!7", "ABC-123", "ABC@123", "ABC 123"]:
        entry["license"] = license_value
        with pytest.raises(ValueError, match=error_message):
            validate_entry(entry)

    # 3. Invalid casing: lowercase and mixed-case letters
    for license_value in ["abcdefg", "AbC1234", "abc1234"]:
        entry["license"] = license_value
        with pytest.raises(ValueError, match=error_message):
            validate_entry(entry)

    # 4. Valid formats: uppercase letters and/or digits, exactly 7 characters
    for license_value in ["7654321", "ABCDEFG", "ABC1234", "WQ13456", "A1B2C3D"]:
        entry["license"] = license_value
        validate_entry(entry)

    # 5. Null is allowed
    entry["license"] = None
    validate_entry(entry)

# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Mutates the salary scheme to test boolean exclusions on rates, missing rate types, and empty dictionary states[cite: 2].
# OUTPUT: None (Test passes if ValueErrors are caught)
def test_salary_scheme_types_and_bounds(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test empty salary scheme dictionary[cite: 2]
    entry["salary_scheme"] = {}
    with pytest.raises(ValueError, match="salary_scheme must contain at least one salary scheme"):
        validate_entry(entry)
        
    # 2. Test boolean passed as a numerical rate (Python treats booleans as integers 1/0, so strict type exclusion is required)[cite: 2]
    entry["salary_scheme"] = {"monthly": {"rate": True, "negotiable": False}}
    with pytest.raises(ValueError, match="salary_scheme.monthly.rate must be a finite number >= 0"):
        validate_entry(entry)
        
    # 3. Test non-boolean passed into negotiable[cite: 2]
    entry["salary_scheme"] = {"monthly": {"rate": 5000.0, "negotiable": "yes"}}
    with pytest.raises(ValueError, match="salary_scheme.monthly.negotiable must be a boolean"):
        validate_entry(entry)


# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Tests edge cases for different contact methods, such as short Telegram handles, bad URLs, and missing methods list[cite: 2].
# OUTPUT: None (Test passes if ValueError is caught)
def test_contact_method_edge_cases(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # 1. Test completely missing methods list[cite: 2]
    entry["contact"] = {"name": "Recruiter"}
    with pytest.raises(ValueError, match="contact.methods must contain at least one method"):
        validate_entry(entry)
        
    # 2. Test Telegram handle that is too short (Under 5 characters)[cite: 2]
    entry["contact"] = {"name": None, "methods": [{"type": "telegram", "identifier": "@abc"}]}
    with pytest.raises(ValueError, match="must be a Telegram handle"):
        validate_entry(entry)
        
    # 3. Test invalid website URL missing a domain dot[cite: 2]
    entry["contact"]["methods"] = [{"type": "website", "identifier": "https://localhost"}]
    with pytest.raises(ValueError, match="must be a valid website URL/domain"):
        validate_entry(entry)
        
    # 4. Test WeChat/WhatsApp with an empty string identifier[cite: 2]
    entry["contact"]["methods"] = [{"type": "wechat", "identifier": "   "}]
    with pytest.raises(ValueError, match="must be a non-empty string"):
        validate_entry(entry)



# INPUT: valid_base_entry (Dictionary fixture)
# PROCESS: Removes optional fields or sets them to empty states to ensure the validator does not enforce optional fields as mandatory[cite: 2].
# OUTPUT: None (Test passes if no exception is raised)
def test_optional_fields_can_be_omitted(valid_base_entry):
    entry = copy.deepcopy(valid_base_entry)
    
    # Remove optional fields from the top level[cite: 2]
    if "benefits" in entry:
        del entry["benefits"]
    if "license" in entry:
        del entry["license"]
        
    # Set nullable fields to None explicitly[cite: 2]
    entry["experience_level"] = None
    entry["contact"]["name"] = None
    
    # Should cleanly pass validation and automatically inject empty arrays/None for missing optional defaults[cite: 2]
    result = validate_entry(entry)
    assert result["benefits"] == []
    assert result["license"] is None









