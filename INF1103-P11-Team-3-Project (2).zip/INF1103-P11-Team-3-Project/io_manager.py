import json
from datetime import datetime, timedelta, timezone

import data_manager


# INPUT: path (string or Path for the database).
# PROCESS: Reads saved IDs and generates default system metadata in Singapore time.
# OUTPUT: Returns a blank report dictionary; raises ValueError for an invalid database.
def new_report(path):
    reports = data_manager.list_reports(path=path)
    now = datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds")
    return {
        "entry_id": max([r["entry_id"] for r in reports], default=0) + 1,
        "job_post_id": max([r["job_post_id"] for r in reports], default=0) + 1,
        "entry_created": now, "date_posted": now,
        "platform": "telegram", "raw_job_posting": "", "manual_entry": True,
        "job_type": "full_time", "experience_level": None, "tasks": [], "benefits": [],
        "location": {"type": "remote", "address": None},
        "contact": {"name": None, "methods": []}, "license": None,
        "salary_scheme": {}, "detected_risks": [], "risk_level": "low"
    }


# INPUT: text (string containing a JSON object or array).
# PROCESS: Parses JSON without letting invalid text become an internal server error.
# OUTPUT: Returns parsed JSON; raises ValueError with a readable message on failure.
def parse_json(text):
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError) as error:
        raise ValueError("Enter valid JSON: " + str(error)) from error

# INPUT: form (Flask form dictionary), metadata (dict).
# PROCESS: Formats the manually entered date into a valid ISO 8601 string. Retains the original time if the date is unchanged, otherwise defaults to midnight SG time.
# OUTPUT: Returns a formatted datetime string.
def _parse_date(form, metadata):
    raw_date = form.get("date_posted", "").strip()
    if len(raw_date) == 10:
        if metadata.get("date_posted", "").startswith(raw_date):
            return metadata["date_posted"]
        return f"{raw_date}T00:00:00+08:00"
    return metadata.get("date_posted")


# INPUT: form (Flask form dictionary), field_name (string).
# PROCESS: Splits a multi-line text area input and removes empty or whitespace-only lines.
# OUTPUT: Returns a clean list of strings.
def _parse_lines(form, field_name):
    return [line.strip() for line in form.get(field_name, "").splitlines() if line.strip()]


# INPUT: form (Flask form dictionary).
# PROCESS: Zips parallel HTML contact arrays into structured dictionaries.
# OUTPUT: Returns a list of contact method dictionaries.
def _parse_contacts(form):
    methods = []
    for kind, identifier in zip(form.getlist("contact_type"), form.getlist("contact_identifier")):
        methods.append({"type": kind, "identifier": identifier.strip()})
    return methods


# INPUT: form (Flask form dictionary).
# PROCESS: Zips parallel HTML salary arrays, applies type conversions for rates and negotiability, and checks for duplicate types.
# OUTPUT: Returns a salary scheme dictionary; raises ValueError for invalid numbers or duplicate types.
def _parse_salaries(form):
    scheme = {}
    for kind, rate, negotiable, label in zip(form.getlist("salary_kind"), form.getlist("salary_rate"),
                                           form.getlist("salary_negotiable"), form.getlist("salary_label")):
        if kind in scheme:
            raise ValueError("salary_scheme contains duplicate salary types")
        try:
            detail = {"rate": float(rate), "negotiable": negotiable == "true"}
        except ValueError as error:
            raise ValueError("salary_scheme.rate must be a number") from error
        if kind == "ad_hoc":
            detail["type"] = label.strip()
        scheme[kind] = detail
    return scheme


# INPUT: form (Flask form dictionary), metadata (server-generated report dictionary).
# PROCESS: Acts as a clean manifest routing form data through parsing helpers to build the nested report.
# OUTPUT: Returns a report dictionary.
def manual_report(form, metadata):
    report = dict(metadata)
    
    report.update({
        "manual_entry": True,
        "date_posted": _parse_date(form, metadata),
        "platform": form.get("platform", ""),
        "raw_job_posting": form.get("raw_job_posting", "").strip(),
        "job_type": form.get("job_type", ""),
        "experience_level": form.get("experience_level") or None,
        "tasks": _parse_lines(form, "tasks"),
        "benefits": _parse_lines(form, "benefits"),
        "license": form.get("license", "").strip() or None,
        "location": {
            "type": form.get("location_type", ""),
            "address": form.get("location_address", "").strip() or None
        },
        "contact": {
            "name": form.get("contact_name", "").strip() or None, 
            "methods": _parse_contacts(form)
        },
        "salary_scheme": _parse_salaries(form),
        "detected_risks": metadata.get("detected_risks", []) 
    })
    
    return report


# INPUT: report (dict representing a complete report), ai_failed (bool).
# PROCESS: Calculates risk or assigns 'tbc' on failure, and validates the entire report.
# OUTPUT: Returns the normalized report dictionary.
def prepare_report(report):
    report = dict(report)

    return data_manager.validate_entry(report)