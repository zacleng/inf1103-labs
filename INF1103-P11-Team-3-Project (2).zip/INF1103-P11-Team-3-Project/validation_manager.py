from datetime import datetime
import math
import re
from urllib.parse import urlparse

import json

# Read the JSON file
with open("data_config.json", "r") as file:
    DATA_CONFIG = json.load(file)

# Convert JSON arrays (lists) back into Python sets
PLATFORMS = set(DATA_CONFIG["PLATFORMS"])
JOB_TYPES = set(DATA_CONFIG["JOB_TYPES"])
EXPERIENCE_LEVELS = set(DATA_CONFIG["EXPERIENCE_LEVELS"])
LOCATION_TYPES = set(DATA_CONFIG["LOCATION_TYPES"])
CONTACT_METHOD_TYPES = set(DATA_CONFIG["CONTACT_METHOD_TYPES"])
SALARY_SCHEME_TYPES = set(DATA_CONFIG["SALARY_SCHEME_TYPES"])
RISK_LEVELS = list(DATA_CONFIG["RISK_LEVELS"])

CORE_REQUIRED_FIELDS = set(DATA_CONFIG["CORE_REQUIRED_FIELDS"])
OPTIONAL_TOP_LEVEL_FIELDS = set(DATA_CONFIG["OPTIONAL_TOP_LEVEL_FIELDS"])

# Dynamically recreate the combined set just like your original code
ALL_TOP_LEVEL_FIELDS = CORE_REQUIRED_FIELDS | OPTIONAL_TOP_LEVEL_FIELDS


# Load the new Single Source of Truth registry
RISK_REGISTRY = DATA_CONFIG["RISK_REGISTRY"]

# --- DYNAMICALLY GENERATED MODULE VARIABLES ---

# 1. Validation Manager: Reconstruct the flat dictionary of sets for report validation
RISK_FLAGS_BY_CATEGORY = {
    category_name: set(data["flags"].keys())
    for category_name, data in RISK_REGISTRY.items()
}

# 2. Risk Schema & Logic Manager: Generate internal snake_case mappings and weights
CATEGORY_KEYS = {
    category_name: data["internal_key"] 
    for category_name, data in RISK_REGISTRY.items()
}

CATEGORIES = {
    data["internal_key"]: [flag_data["internal_factor"] for flag_data in data["flags"].values()]
    for data in RISK_REGISTRY.values()
}

REPORT_FLAG_FACTORS = {
    display_flag: flag_data["internal_factor"]
    for category_data in RISK_REGISTRY.values()
    for display_flag, flag_data in category_data["flags"].items()
}

INDICATOR_ALIASES = {
    flag_data["internal_factor"]: flag_data.get("aliases", [])
    for category_data in RISK_REGISTRY.values()
    for flag_data in category_data["flags"].values()
}

FLAG_WEIGHTS = {
    flag_data["internal_factor"]: flag_data["weight"]
    for category_data in RISK_REGISTRY.values()
    for flag_data in category_data["flags"].values()
}



# INPUT: value (any type), field (string representing the field name)
# PROCESS: Verifies that the provided value is a dictionary (representing a JSON object).
# OUTPUT: Returns the original dictionary value if valid, otherwise raises a ValueError.
def _object(value, field):
    # Check if the value type is a dictionary
    if not isinstance(value, dict):
        raise ValueError(f"{field} must be a JSON object/dictionary")
    # Return the validated dictionary
    return value

# INPUT: value (any type), field (string representing the field name), nullable (boolean indicating if None is allowed)
# PROCESS: Checks if the value is a string, ensures it's not empty/blank, and handles optional nullability.
# OUTPUT: Returns a stripped string (or None if nullable and value is None), otherwise raises a ValueError.
def _string(value, field, nullable=False):
    # Allow None if the nullable flag is set to True
    if nullable and value is None:
        return None
    # Check if the value is not a string, or if it's an empty/whitespace-only string
    if not isinstance(value, str) or not value.strip():
        # Dynamically build the error message suffix if nullable
        suffix = " or null" if nullable else ""
        raise ValueError(f"{field} must be a non-empty string{suffix}")
    # Return the string with leading and trailing whitespaces removed
    return value.strip()

# INPUT: value (any type), field (string representing the field name), minimum (optional integer for lower bound)
# PROCESS: Validates that the value is strictly an integer (excluding booleans) and optionally checks if it meets a minimum threshold.
# OUTPUT: Returns the validated integer, otherwise raises a ValueError.
def _integer(value, field, minimum=None):
    # Exclude booleans (which Python considers integers) and verify it's an int
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an integer")
    # Check against the minimum threshold if one is provided
    if minimum is not None and value < minimum:
        raise ValueError(f"{field} must be >= {minimum}")
    # Return the validated integer
    return value

# INPUT: value (any type), allowed (iterable of allowed values), field (string representing the field name)
# PROCESS: Checks if the provided value exists within the given collection of allowed values.
# OUTPUT: Returns the value if it's in the allowed collection, otherwise raises a ValueError.
def _enum(value, allowed, field):
    try:
        # Check if the value is present in the allowed set/list
        valid = value in allowed
    except TypeError:
        # Handle unhashable types being checked against a set
        valid = False
    if not valid:
        # Format the allowed values as a sorted, comma-separated string for the error message
        raise ValueError(f"{field} must be one of: {', '.join(map(str, sorted(allowed, key=str)))}")
    # Return the validated enumeration value
    return value

# INPUT: value (any type), field (string representing the field name)
# PROCESS: Validates the value is a non-empty string, parses it as an ISO 8601 datetime, and ensures it includes timezone information.
# OUTPUT: Returns the stripped, validated datetime string, otherwise raises a ValueError.
def _datetime(value, field):
    # Ensure the value is a valid, non-empty string
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be an ISO 8601 date-time string")
    try:
        # Attempt to parse the ISO format string, replacing 'Z' with explicit UTC offset for compatibility
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as exc:
        # Catch parsing errors and raise a custom validation error
        raise ValueError(f"{field} must be a valid ISO 8601 date-time string") from exc
    # Ensure the parsed datetime is timezone-aware
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field} must include a timezone/UTC offset (for example +08:00 or Z)")
    # Return the stripped original valid string
    return value.strip()


# INPUT: value (any type)
# PROCESS: Validates that the value belongs to the predefined PLATFORMS enum.
# OUTPUT: Returns the validated platform string.
def validate_platform(value): return _enum(value, PLATFORMS, "platform")

# INPUT: value (any type)
# PROCESS: Validates that the value belongs to the predefined JOB_TYPES enum.
# OUTPUT: Returns the validated job type string.
def validate_job_type(value): return _enum(value, JOB_TYPES, "job_type")

# INPUT: value (any type)
# PROCESS: Validates that the value belongs to the predefined EXPERIENCE_LEVELS enum.
# OUTPUT: Returns the validated experience level string (or None).
def validate_experience_level(value): return _enum(value, EXPERIENCE_LEVELS, "experience_level")

# INPUT: value (any type)
# PROCESS: Validates that the value belongs to the predefined LOCATION_TYPES enum.
# OUTPUT: Returns the validated location type string.
def validate_location_type(value): return _enum(value, LOCATION_TYPES, "location.type")

# INPUT: value (any type)
# PROCESS: Validates that the value belongs to the predefined RISK_LEVELS enum.
# OUTPUT: Returns the validated risk level string.
def validate_risk_level(value): return _enum(value, RISK_LEVELS, "risk_level")

# INPUT: value (any type)
# PROCESS: Validates that the value is an integer with a minimum of 1.
# OUTPUT: Returns the validated entry_id integer.
def validate_entry_id(value): return _integer(value, "entry_id", 1)

# INPUT: value (any type)
# PROCESS: Validates that the value is an integer with a minimum of 1.
# OUTPUT: Returns the validated job_post_id integer.
def validate_job_post_id(value): return _integer(value, "job_post_id", 1)

# INPUT: value (any type)
# PROCESS: Validates that the value is a proper ISO 8601 datetime string.
# OUTPUT: Returns the validated entry_created datetime string.
def validate_entry_created(value): return _datetime(value, "entry_created")

# INPUT: value (any type)
# PROCESS: Validates that the value is a proper ISO 8601 datetime string.
# OUTPUT: Returns the validated date_posted datetime string.
def validate_date_posted(value): return _datetime(value, "date_posted")

# INPUT: value (any type)
# PROCESS: Validates that the value is a non-empty string.
# OUTPUT: Returns the validated raw_job_posting string.
def validate_raw_job_posting(value): return _string(value, "raw_job_posting")

# INPUT: value (any type)
# PROCESS: Validates that the value is a non-empty string.
# OUTPUT: Returns the validated task string.
def validate_task(value): return _string(value, "task")

# INPUT: value (any type)
# PROCESS: Validates that the value is a non-empty string.
# OUTPUT: Returns the validated benefit string.
def validate_benefit(value): return _string(value, "benefit")


# INPUT: raw (dictionary representing location data)
# PROCESS: Validates location fields, ensuring no unexpected fields exist, 'type' is present, and 'address' exists if required by the location type.
# OUTPUT: Returns a cleaned dictionary containing validated 'type' and 'address'.
def validate_location(raw):
    # Ensure the raw input is a dictionary
    loc = _object(raw, "location")
    # Identify if there are any keys other than 'type' and 'address'
    if set(loc) - {"type", "address"}:
        raise ValueError("location contains unexpected fields")
    # Check that the mandatory 'type' field is provided
    if "type" not in loc:
        raise ValueError("Missing required field: location.type")
    # Validate the location type using the specific enum validator
    kind = validate_location_type(loc["type"])
    # Validate the address, allowing it to be null
    address = _string(loc.get("address"), "location.address", nullable=True)
    # Conditionally require an address if the location type is onsite or hybrid
    if kind in {"onsite", "hybrid"} and address is None:
        raise ValueError(f"location.address is required when location.type is {kind!r}")
    # Return the normalized location dictionary
    return {"type": kind, "address": address}

# INPUT: kind (string contact type), identifier (string contact value), field (string field name for errors)
# PROCESS: Applies specific regular expressions or string checks based on the contact method kind.
# OUTPUT: None (Implicitly returns if successful, otherwise raises ValueError).
def _validate_contact_identifier(kind, identifier, field):
    if kind == "email":
        # FIXED: Removed double backslashes for \s and \.
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", identifier):
            raise ValueError(f"{field} must look like a valid email address")
    elif kind == "phone":
        # FIXED: Removed double backslashes for \+ and \s
        if not re.fullmatch(r"\+?[0-9][0-9\s().-]{5,24}", identifier) or sum(c.isdigit() for c in identifier) < 7:
            raise ValueError(f"{field} must look like a phone number; keep it as a string")
    elif kind == "telegram":
        handle = identifier[1:] if identifier.startswith("@") else identifier
        if not re.fullmatch(r"[A-Za-z0-9_]{5,32}", handle):
            raise ValueError(f"{field} must be a Telegram handle (5-32 letters, digits or underscores; optional @)")
    elif kind == "website":
        parsed = urlparse(identifier if "://" in identifier else "https://" + identifier)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or "." not in parsed.netloc:
            raise ValueError(f"{field} must be a valid website URL/domain")
    elif kind in {"whatsapp", "wechat", "other"} and not identifier.strip():
        raise ValueError(f"{field} must not be empty")

# INPUT: raw (dictionary representing contact data)
# PROCESS: Validates the overall contact object, ensuring correct fields, formats, and checking for duplicate methods.
# OUTPUT: Returns a cleaned dictionary containing validated 'name' and 'methods' list.
def validate_contact(raw):
    # Ensure the raw input is a dictionary
    contact = _object(raw, "contact")
    # Identify if there are any keys other than 'name' and 'methods'
    if set(contact) - {"name", "methods"}:
        raise ValueError("contact contains unexpected fields")
    # Validate the name, allowing it to be null
    name = _string(contact.get("name"), "contact.name", nullable=True)
    # Extract the methods list
    methods = contact.get("methods")
    # Ensure methods is a list and contains at least one item
    if not isinstance(methods, list) or len(methods) < 1:
        raise ValueError("contact.methods must contain at least one method")
    
    clean, seen = [], set()
    # Iterate through each contact method
    for i, item in enumerate(methods):
        field = f"contact.methods[{i}]"
        # Validate that the individual method is a dictionary
        method = _object(item, field)
        # Enforce exact keys 'type' and 'identifier'
        if set(method) != {"type", "identifier"}:
            raise ValueError(f"{field} must have exactly type and identifier")
        # Validate the method type against known enums
        kind = _enum(method["type"], CONTACT_METHOD_TYPES, field + ".type")
        # Validate that the identifier is a string
        identifier = _string(method["identifier"], field + ".identifier")
        # Delegate format validation of the identifier based on its kind
        _validate_contact_identifier(kind, identifier, field + ".identifier")
        
        pair = (kind, identifier)
        # Check if this exact type and identifier combination has already been processed
        if pair in seen:
            raise ValueError(f"contact.methods contains duplicate method {pair!r}")
        seen.add(pair)
        # Append the cleaned method to our output list
        clean.append({"type": kind, "identifier": identifier})
    # Return the normalized contact structure
    return {"name": name, "methods": clean}

# INPUT: raw (dictionary mapping scheme types to their details)
# PROCESS: Validates each provided salary scheme ensuring required keys, positive finite rates, and valid types.
# OUTPUT: Returns a cleaned dictionary of valid salary schemes and their normalized properties.
def validate_salary_scheme(raw):
    # Ensure the salary_scheme input is a dictionary
    salary = _object(raw, "salary_scheme")
    # Reject an empty salary scheme dictionary
    if not salary:
        raise ValueError("salary_scheme must contain at least one salary scheme")
    # Check if any provided keys are not in the predefined allowed types
    if set(salary) - SALARY_SCHEME_TYPES:
        raise ValueError("Unsupported salary scheme(s): " + ", ".join(sorted(set(salary) - SALARY_SCHEME_TYPES)))
    
    clean = {}
    # Iterate over each provided scheme type and its detail dictionary
    for kind, detail in salary.items():
        field = f"salary_scheme.{kind}"
        # Validate that the details for the scheme is a dictionary
        scheme = _object(detail, field)
        # Determine the expected keys dynamically based on the scheme type ('ad_hoc' requires 'type')
        expected = {"rate", "negotiable", "type"} if kind == "ad_hoc" else {"rate", "negotiable"}
        # Ensure the schema structure matches exactly what is expected
        if set(scheme) != expected:
            raise ValueError(f"{field} must contain exactly: {', '.join(sorted(expected))}")
        
        rate = scheme["rate"]
        # Validate that rate is a positive, finite float or int (excluding booleans)
        if isinstance(rate, bool) or not isinstance(rate, (int, float)) or not math.isfinite(float(rate)) or rate < 0:
            raise ValueError(f"{field}.rate must be a finite number >= 0")
        # Ensure 'negotiable' is strictly a boolean
        if not isinstance(scheme["negotiable"], bool):
            raise ValueError(f"{field}.negotiable must be a boolean")
        
        # Save the validated standard fields
        clean[kind] = {"rate": rate, "negotiable": scheme["negotiable"]}
        # Process the extra 'type' field specifically for 'ad_hoc' schemes
        if kind == "ad_hoc":
            clean[kind]["type"] = _string(scheme["type"], field + ".type")
    # Return the normalized salary schemes
    return clean

# INPUT: raw (list of dictionaries representing detected risks)
# PROCESS: Iterates through risks, confirming correct structure, matching category-to-flag constraints, and preventing duplicates.
# OUTPUT: Returns a cleaned list of valid risk dictionaries.
def validate_detected_risks(raw):

    if isinstance(raw, dict):
        raw = [raw]
    # Enforce that the input must be a list

    if isinstance(raw, dict):
        raw = [raw]
    if not isinstance(raw, list):
        raise ValueError("detected_risks must be a list (use [] when no risks are detected)")
    
    clean, seen = [], set()
    # Iterate over each risk dictionary in the list
    for i, item in enumerate(raw):
        field = f"detected_risks[{i}]"
        # Verify the item is a dictionary
        finding = _object(item, field)
        # Ensure it contains exactly the four required fields
        if set(finding) != {"category", "flag", "cite", "reasoning"}:
            raise ValueError(f"{field} must have category, flag, cite and reasoning")
        
        # Validate the category against the predefined top-level keys
        category = _enum(finding["category"], set(RISK_FLAGS_BY_CATEGORY), field + ".category")
        # Validate the flag is a string
        flag = _string(finding["flag"], field + ".flag")
        # Verify that the provided flag exists within the selected category's allowed list
        if flag not in RISK_FLAGS_BY_CATEGORY[category]:
            raise ValueError(f"{field}.flag {flag!r} is not valid for category {category!r}")
        
        # Validate cite and reasoning fields as regular strings
        cite = _string(finding["cite"], field + ".cite")
        reasoning = _string(finding["reasoning"], field + ".reasoning")
        
        pair = (category, flag)
        # Detect and reject duplicate risks based on their category and flag combination
        if pair in seen:
            raise ValueError(f"detected_risks contains duplicate category/flag {pair!r}")
        seen.add(pair)
        # Add the validated risk to the output list
        clean.append({"category": category, "flag": flag, "cite": cite, "reasoning": reasoning})
    # Return the clean list of detected risks
    return clean

def validate_license(raw):
    if raw is not None:
        # If present, validate it's a string
        raw = _string(raw, "license")
        # Ensure the string strictly matches the format
        raw = raw.removeprefix("EA")
    if raw is not None and not re.fullmatch(r"[A-Z0-9]{7}", raw):
        raise ValueError("license must be null or contain exactly 7 uppercase alphanumeric characters")
    return raw

def validate_benefits(raw):
    # Ensure benefits is a list
    if not isinstance(raw, list):
        raise ValueError("benefits must be a list")
    # Validate each benefit as a string
    return [_string(v, f"benefits[{i}]") for i, v in enumerate(raw)]

def validate_tasks(raw):
    # Ensure tasks is a list and contains at least one item
    if not isinstance(raw, list) or not raw:
        raise ValueError("tasks must contain at least one item")
    return [_string(v, f"tasks[{i}]") for i, v in enumerate(raw)]

# INPUT: raw (dictionary representing a single, full job posting report)
# PROCESS: Checks required and optional top-level fields, ensures types are correct, delegates nested object validations, and constructs a pristine data structure.
# OUTPUT: Returns a normalized dictionary of the complete valid report.
def validate_entry(raw):
    """Validate and return a normalized copy of one complete report."""
    # Ensure the top-level report is a dictionary
    entry = _object(raw, "report")
    
    # Check for missing strictly required fields
    missing = CORE_REQUIRED_FIELDS - set(entry)
    # Check for fields that are completely unrecognized
    extra = set(entry) - ALL_TOP_LEVEL_FIELDS
    if missing:
        raise ValueError("Missing required field(s): " + ", ".join(sorted(missing)))
    if extra:
        raise ValueError("Unexpected field(s): " + ", ".join(sorted(extra)))
    
    # Ensure manual_entry is strictly a boolean value
    if not isinstance(entry["manual_entry"], bool):
        raise ValueError("manual_entry must be a boolean")
    
    



        
    # Reconstruct and return the fully validated object, delegating subset validations
    result = {
        "entry_id": validate_entry_id(entry["entry_id"]),
        "job_post_id": validate_job_post_id(entry["job_post_id"]),
        "platform": validate_platform(entry["platform"]),
        "raw_job_posting": validate_raw_job_posting(entry["raw_job_posting"]),
        "manual_entry": entry["manual_entry"],
        "entry_created": validate_entry_created(entry["entry_created"]),
        "job_type": validate_job_type(entry["job_type"]),
        "experience_level": validate_experience_level(entry["experience_level"]),
        "tasks": validate_tasks(entry.get("tasks")),
        "date_posted": validate_date_posted(entry["date_posted"]),
        "benefits": validate_benefits(entry.get("benefits", [])),
        "location": validate_location(entry["location"]),
        "contact": validate_contact(entry["contact"]),
        "license": validate_license(entry.get("license")),
        "salary_scheme": validate_salary_scheme(entry["salary_scheme"]),
        "detected_risks": validate_detected_risks(entry["detected_risks"]),
        "risk_level": validate_risk_level(entry["risk_level"]),
    }
    return result

# INPUT: raw (list representing the entire JSON database of reports)
# PROCESS: Verifies the input is a list, determines the highest existing ID, iterates through each entry, proactively assigns a new valid ID for invalid or duplicate IDs (prioritizing earlier indices), and normalizes each entry.
# OUTPUT: Returns a list of completely validated and normalized report dictionaries.
def validate_reports(raw, drop =True):
    """Validate the whole JSON database (top-level array); return normalized reports."""
    if not isinstance(raw, list):
        raise ValueError("JSON database must be a top-level array/list of report objects")
    
    # Determine the highest valid entry_id currently in the dataset to safely generate new ones
    max_id = max((item["entry_id"] for item in raw 
                  if isinstance(item, dict) and isinstance(item.get("entry_id"), int)), default=0)
    
    reports, ids = [], set()
    
    # Process each report object in the array
    for i, item in enumerate(raw):
        if isinstance(item, dict):
            current_id = item.get("entry_id")
            
            # Reassign if the ID is missing, not an integer, <= 0, or already exists in the 'ids' set
            if not isinstance(current_id, int) or current_id <= 0 or current_id in ids:
                max_id += 1
                item["entry_id"] = max_id
                raise ValueError("ID is missing / a duplicate, rectified, please reload")
                
        try:
            # Delegate validation of the individual report
            clean = validate_entry(item)
        except ValueError as exc:
            if drop:
                continue
            # Catch errors to provide context on exactly which index failed
            raise ValueError(f"Report at index {i} is invalid: {exc}") from exc
            
        ids.add(clean["entry_id"])
        # Append the successfully validated report
        reports.append(clean)
        
    # Return the fully processed database list
    return reports


# INPUT: None
# PROCESS: Iterates through RULES and validates that every factor exists in the SSOT config (FLAG_WEIGHTS).
# OUTPUT: Raises ValueError on startup if an unknown factor or invalid level is found.
def _validate_rules_against_registry(rules):
    valid_factors = set(FLAG_WEIGHTS.keys())
    for rule_name, target_level, clauses in rules:
        if target_level not in RISK_LEVELS:
            raise ValueError(f"Rule '{rule_name}' has invalid target level: '{target_level}'")
        for clause in clauses:
            for factor in clause:
                if factor not in valid_factors:
                    raise ValueError(f"Rule '{rule_name}' contains unknown factor '{factor}'. Must be defined in data_config.json RISK_REGISTRY.")