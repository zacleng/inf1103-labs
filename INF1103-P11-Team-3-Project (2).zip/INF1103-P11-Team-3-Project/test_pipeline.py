"""Offline AI-schema and Flask pipeline checks; no live API requests."""

import json
from unittest.mock import patch

import ai_manager
from test_logic_manager import record
from web import app


def run_checks():
    analysis = record("otp_request")
    assert ai_manager.validate_response(analysis)
    with patch.object(ai_manager, "call_api", return_value=json.dumps(analysis)):
        assert ai_manager.analyze_job({"title": "Assistant"}) == analysis
        client = app.test_client()
        response = client.post("/submit", json={
            "job_title": "Assistant", "job_description": "Send your OTP to apply"
        })
        assert response.status_code == 200
        decision = response.get_json()["data"]
        assert decision["risk_level"] == "Critical" and decision["score"] == 50
        assert decision["route"] == "stop_interaction"
        assert "risk_score" not in decision
    for raw in (None, "not JSON", json.dumps({"risk_score": 0, "risk_level": "low"})):
        with patch.object(ai_manager, "call_api", return_value=raw):
            assert ai_manager.analyze_job({}) is None
    client = app.test_client()
    for invalid in ({}, [], {"job_title": 42}, {"job_title": ""}):
        assert client.post("/submit", json=invalid).status_code == 400
    with patch.object(ai_manager, "analyze_job", return_value=None):
        assert client.post("/submit", json={"job_title": "A", "job_description": "B"}).status_code == 500
    with patch.object(ai_manager, "analyze_job", return_value=record(sufficient=False)):
        decision = client.post("/submit", json={"job_title": "A", "job_description": "B"}).get_json()["data"]
        assert decision["risk_level"] is None
        assert decision["status"] == "needs_more_information"
    print("AI contract and web pipeline checks passed (API mocked).")


if __name__ == "__main__":
    run_checks()
