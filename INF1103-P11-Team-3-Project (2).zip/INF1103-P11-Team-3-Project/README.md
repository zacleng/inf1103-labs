

### Resetting Environment:
**Using Bash**
1. `pip freeze | xargs pip uninstall -y && pip install --no-cache-dir -r requirements.txt`

**Using PowerShell:**

1. `pip freeze | ForEach-Object { pip uninstall -y $_ } ; pip install --no-cache-dir -r requirements.txt`

**Using Command Prompt (cmd):**

1. `(for /f "delims=" %i in ('pip freeze') do pip uninstall -y "%i") && pip install --no-cache-dir -r requirements.txt`


### Using Docker to run app

**Using Bash, PowerShell, Command Prompt:**
1. `docker compose up --build --exit-code-from app --remove-orphans`


### Running Docker Test Files

**Using Bash, PowerShell, Command Prompt:**
1. `docker build -f Pytest.Dockerfile -t app_test . && docker run --rm app_test`





## System Architecture & File Breakdown

This project follows a modular, separation-of-concerns architecture. The system is divided into routing, data validation, business logic (risk calculation), AI integration, and persistence.

### 1. Core Backend & Application Logic

*   **`app.py`**
    *   **Function:** The central Flask application and routing controller.
    *   **Key Features:** 
        *   Handles web routes (`/`, `/report/new`, `/report/<id>`, etc.).
        *   Orchestrates the pipeline: receives form data -> calls `process_and_analyze_form` (which uses `io_manager`, `ai_manager`, and `logic_manager`) -> saves via `data_manager`.
        *   Manages dynamic filtering and sorting for the dashboard (`dashboard_filters`, `filter_nested_reports`).
        *   Handles signed payloads to prevent tampering with hidden form fields.

*   **`io_manager.py`**
    *   **Function:** Form data mapper and normalizer.
    *   **Key Features:** 
        *   `manual_report`: Converts flat HTML form data (strings, arrays) into the nested Python dictionary structure required by the database.
        *   Parses and formats dates (`_parse_date`), repeatable contacts (`_parse_contacts`), and nested salary structures (`_parse_salaries`).
        *   `new_report`: Generates a blank, schema-compliant template for new entries.

*   **`validation_manager.py`**
    *   **Function:** The strict schema gatekeeper.
    *   **Key Features:**
        *   Validates every field of a report before it is saved (`validate_entry`, `validate_reports`).
        *   Enforces data types, regex patterns (e.g., email/phone formats), and ensures values match the enums defined in `data_config.json`.
        *   Dynamically generates rules based on the SSOT (Single Source of Truth) configuration.

*   **`logic_manager.py`**
    *   **Function:** The domain brain for risk assessment.
    *   **Key Features:**
        *   `adapt_analysis`: Maps textual AI findings to internal boolean risk flags using aliases.
        *   `_calculate_base_score`: Assigns point values to detected risks based on configured weights.
        *   `_apply_rules`: Checks for multi-condition "domain brain" rules (e.g., Phishing Trap, Ghost Employer Fee Trap) to force critical risk levels.
        *   `calculate_risk_level`: Computes the final risk badge (Low, Medium, High, Critical).

### 2. AI Integration

*   **`ai_manager.py`**
    *   **Function:** Handles the LLM interaction specifically for *Risk Analysis*.
    *   **Key Features:**
        *   Builds structured prompts using `prompt.txt` (`build_prompt`).
        *   Calls Gemini API natively, with a graceful fallback to a local Ollama model if Gemini fails or is unconfigured (`call_api`, `_call_ollama`).
        *   Cleans and parses the AI's JSON output (`_parse_and_validate`).

*   **`autofill_manager.py`**
    *   **Function:** Handles the LLM interaction for *Form Auto-filling* (Data Extraction).
    *   **Key Features:**
        *   `extract_job_posting`: Takes a raw text job description and asks the AI to map it strictly to the application's JSON schema (excluding risk evaluation).
        *   Also features a primary-Gemini, fallback-Ollama architecture.

### 3. Database & Data Management

*   **`json_db.py`**
    *   **Function:** Custom, file-based JSON database engine.
    *   **Key Features:**
        *   Handles all CRUD operations (`create_report`, `get_report`, `update_report`, `delete_report`, `list_reports`).
        *   `_atomic_write`: Uses temporary files and `os.replace` to guarantee data integrity and prevent file corruption during concurrent saves.
        *   Provides advanced nested field querying and filtering.

*   **`data_manager.py`**
    *   **Function:** A clean facade wrapper.
    *   **Key Features:** Exposes the safe CRUD operations from `json_db.py` and the validation methods from `validation_manager.py` to the rest of the app.

### 4. Configuration

*   **`data_config.json`**
    *   **Function:** The Single Source of Truth (SSOT).
    *   **Key Features:** Defines all platforms, job types, risk levels, and the complete `RISK_REGISTRY` (categories, flags, weights, and aliases). Keeps the backend, frontend dropdowns, and AI prompts perfectly synchronized.
*   **`prompt.txt`**
    *   **Function:** Base instructions for the AI risk analyzer, defining the expected JSON array output format.

### 5. Frontend (UI/UX)

*   **`base.html` & `io.css`**: The master layout and global styling, including responsive design and color-coded risk badges.
*   **`dashboard.html`**: The main index view displaying saved reports, with advanced filtering panels and sorting toolbars.
*   **`entry_form.html`**: The shared form template for creating and editing reports, featuring an "Auto-fill with AI" button.
*   **`io_fields.html`**: A library of reusable Jinja2 macros for generating standard form inputs and repeatable rows (contacts, salaries).
*   **`report_view.html`**: The read-only detail page for a specific report, neatly displaying all extracted data and AI reasoning.
*   **`io_form.js`**: Client-side JavaScript that manages dynamic form behaviors (adding/removing rows), handles live debounced validation, and manages the asynchronous fetch request for the AI auto-fill feature.
*   **`index.html`**: A lightweight, standalone SPA (Single Page Application) version of the tool for quick, one-off analyses.

### 6. Infrastructure

*   **`Dockerfile`**: Defines the Python environment and dependencies required to run the Flask application.
*   **`compose.yaml`**: Docker Compose configuration that orchestrates the main application container alongside a local `ollama` container, automatically pulling the required local models on startup.

### How to run the project
1. python web.py
2. open the url provide in cmd "http://127.0.0.1:5000"
3. fill the survey
4. Wait for AI response

### AI Model using
Gemini 3.8-flash / gemini-3.5-flash
- Use 3.5 is because 3.8 sometime invalid due to high demand. 


