const form = document.getElementById('entry-form');
const toggle = document.getElementById('toggle-entry-mode');
const manualSection = document.getElementById('manual-entry-section');
// const riskOptions = JSON.parse(document.getElementById('risk-options').textContent);
let rowNumber = 1000;
let validationTimer;
let validationVersion = 0;
let submitting = false;

// Handle AI Auto-fill Preprocessor
const btnAutofill = document.getElementById('btn-autofill');
if (btnAutofill) {
    btnAutofill.addEventListener('click', async function() {
        const raw = document.getElementById('raw-job-posting').value;
        const status = document.getElementById('autofill-status');
        
        if (!raw.trim()) {
            status.textContent = 'Please paste a job posting first.';
            return;
        }
        
        btnAutofill.disabled = true;
        status.textContent = 'Extracting data... this may take a few seconds.';
        
        try {
            const formData = new FormData(form);
            const response = await fetch('/report/autofill', { method: 'POST', body: formData });
            if (!response.ok) throw new Error((await response.json()).error || 'Auto-fill failed.');
            
            const data = await response.json();
            
            // Populate Basic Fields
            if (data.date_posted) document.getElementById('date-posted').value = data.date_posted.substring(0, 10);
            if (data.platform) document.getElementById('platform').value = data.platform;
            if (data.job_type) document.getElementById('job-type').value = data.job_type;
            if (data.experience_level) document.getElementById('experience-level').value = data.experience_level;
            if (data.license) document.getElementById('license').value = data.license;
            if (data.tasks) document.getElementById('tasks').value = Array.isArray(data.tasks) ? data.tasks.join('\n') : data.tasks;
            if (data.benefits) document.getElementById('benefits').value = Array.isArray(data.benefits) ? data.benefits.join('\n') : data.benefits;
            if (data.location) {
                if (data.location.type) document.getElementById('location-type').value = data.location.type;
                if (data.location.address) document.getElementById('location-address').value = data.location.address;
            }
            if (data.contact && data.contact.name) document.getElementById('contact-name').value = data.contact.name;
            
            // Populate Contacts
            if (data.contact && Array.isArray(data.contact.methods) && data.contact.methods.length > 0) {
                const contactRows = document.getElementById('contact-rows');
                contactRows.innerHTML = ''; 
                data.contact.methods.forEach(method => {
                    const template = document.getElementById('contact-template');
                    const content = template.content.cloneNode(true);
                    rowNumber++;
                    content.querySelectorAll('[id], [for], [aria-describedby]').forEach(el => {
                        ['id', 'for', 'aria-describedby'].forEach(attr => {
                            if (el.hasAttribute(attr)) el.setAttribute(attr, el.getAttribute(attr).replace(/new/g, rowNumber));
                        });
                    });
                    content.querySelector('[name="contact_type"]').value = method.type || 'email';
                    content.querySelector('[name="contact_identifier"]').value = method.identifier || '';
                    contactRows.appendChild(content);
                });
            }
            
            // Populate Salary
            if (data.salary_scheme && Object.keys(data.salary_scheme).length > 0) {
                const salaryRows = document.getElementById('salary-rows');
                salaryRows.innerHTML = '';
                for (const [kind, detail] of Object.entries(data.salary_scheme)) {
                    const template = document.getElementById('salary-template');
                    const content = template.content.cloneNode(true);
                    rowNumber++;
                    content.querySelectorAll('[id], [for], [aria-describedby]').forEach(el => {
                        ['id', 'for', 'aria-describedby'].forEach(attr => {
                            if (el.hasAttribute(attr)) el.setAttribute(attr, el.getAttribute(attr).replace(/new/g, rowNumber));
                        });
                    });
                    content.querySelector('[name="salary_kind"]').value = kind;
                    content.querySelector('[name="salary_rate"]').value = detail.rate || '';
                    content.querySelector('[name="salary_negotiable"]').value = detail.negotiable ? 'true' : 'false';
                    content.querySelector('[name="salary_label"]').value = detail.type || '';
                    salaryRows.appendChild(content);
                }
            }

            status.textContent = 'Auto-fill complete! You can now review and edit the fields.';
            validateForm(); 
            
        } catch (error) {
            status.textContent = error.message;
        } finally {
            btnAutofill.disabled = false;
        }
    });
}

function showError(field, message) {
    const error = document.getElementById('error-' + field.id);
    if (!error) return;
    error.textContent = message;
    error.style.display = message ? 'block' : 'none';
    field.setAttribute('aria-invalid', message ? 'true' : 'false');
}

// Map the validator's nested field names to the corresponding visible form row.
function showServerError(message) {
    let field;
    const contact = message.match(/contact\.methods\[(\d+)\](?:\.(type|identifier))?/);
    const risk = message.match(/detected_risks\[(\d+)\](?:\.(category|flag|cite|reasoning))?/);
    const salary = message.match(/salary_scheme\.([a-z_]+)(?:\.(rate|negotiable|type))?/);
    if (contact) {
        const row = document.querySelectorAll('#contact-rows .repeat-row')[Number(contact[1])];
        if (row) field = row.querySelector('[name="contact_' + (contact[2] || 'identifier') + '"]');
    } else if (risk) {
        const row = document.querySelectorAll('#risk-rows .repeat-row')[Number(risk[1])];
        if (row) field = row.querySelector('[name="risk_' + (risk[2] || 'flag') + '"]');
    } else if (salary) {
        document.querySelectorAll('#salary-rows .repeat-row').forEach(function(row) {
            if (row.querySelector('[name="salary_kind"]').value === salary[1]) {
                field = row.querySelector('[name="salary_' + (salary[2] === 'type' ? 'label' : salary[2] || 'rate') + '"]');
            }
        });
    }
    if (!field) {
        const mappings = {
            'raw_job_posting': 'raw-job-posting', 'job_type': 'job-type',
            'experience_level': 'experience-level', 'location.address': 'location-address',
            'location.type': 'location-type', 'contact.name': 'contact-name',
            'contact.methods': 'contact-identifier-', 'salary_scheme': 'salary-rate-',
            'detected_risks': 'risk-flag-', 'license': 'license', 'tasks': 'tasks',
            'benefits': 'benefits', 'platform': 'platform'
        };
        for (const name in mappings) {
            if (message.includes(name)) {
                field = document.querySelector('[id^="' + mappings[name] + '"]:not(.error-message)');
                break;
            }
        }
    }
    if (field) showError(field, message);
    document.getElementById('form-status').textContent = message;
}

async function validateForm() {
    const currentVersion = ++validationVersion;
    form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(function(field) {
        if (!field.disabled) showError(field, field.validity.valid ? '' : field.validationMessage);
    });
    if (!form.checkValidity()) return false;
    if (document.getElementById('entry-mode').value === 'auto') return true;
    try {
        const response = await fetch('/report/validate', {method: 'POST', body: new FormData(form)});
        const result = await response.json();
        // An older response must not overwrite a more recent field change.
        if (currentVersion !== validationVersion) return false;
        if (!result.valid) showServerError(result.message);
        else document.getElementById('form-status').textContent = '';
        return result.valid;
    } catch (error) {
        document.getElementById('form-status').textContent = 'Could not validate the form. Please try again.';
        return false;
    }
}

form.addEventListener('input', function(event) {
    if (event.target.matches('input, select, textarea')) {
        validationVersion++;
        showError(event.target, event.target.validity.valid ? '' : event.target.validationMessage);
        clearTimeout(validationTimer);
        validationTimer = setTimeout(validateForm, 400);
    }
});
// form.addEventListener('change', function(event) {
//     if (event.target.name === 'risk_category') {
//         const flag = event.target.closest('.repeat-row').querySelector('[name="risk_flag"]');
//         flag.replaceChildren();
//         riskOptions[event.target.value].forEach(function(value) { flag.add(new Option(value, value)); });
//     }
//     if (event.target.name === 'salary_kind') {
//         event.target.closest('.repeat-row').querySelector('[name="salary_label"]').required = event.target.value === 'ad_hoc';
//     }
//     if (event.target.name === 'location_type') {
//         document.getElementById('location-address').required = event.target.value !== 'remote';
//     }
//     clearTimeout(validationTimer);
//     validationTimer = setTimeout(validateForm, 400);
// });
form.addEventListener('click', function(event) {
    if (event.target.dataset.add) {
        const group = event.target.dataset.add;
        const template = document.getElementById(group + '-template');
        const content = template.content.cloneNode(true);
        rowNumber++;
        content.querySelectorAll('[id], [for], [aria-describedby]').forEach(function(element) {
            ['id', 'for', 'aria-describedby'].forEach(function(attribute) {
                if (element.hasAttribute(attribute)) element.setAttribute(attribute, element.getAttribute(attribute).replace(/new/g, rowNumber));
            });
        });
        document.getElementById(group + '-rows').appendChild(content);
    }
    if (event.target.classList.contains('remove-row')) {
        event.target.closest('.repeat-row').remove();
        validateForm();
    }
});
form.addEventListener('submit', async function(event) {
    event.preventDefault();
    if (submitting) return;
    submitting = true;
    clearTimeout(validationTimer);
    if (await validateForm()) {
        form.querySelector('button[type="submit"]').disabled = true;
        document.getElementById('form-status').textContent = 'Processing the report. Please wait...';
        form.submit();
    }
    else {
        submitting = false;
        const invalid = form.querySelector('[aria-invalid="true"]:not(:disabled)');
        if (invalid) invalid.focus();
    }
});
