# ai_manager.py

import json
import logging

logger = logging.getLogger(__name__)


def build_prompt(record):
    """
    Build a structured prompt from a job record.
    """

    prompt = f"""
You are a job scam detection assistant.

Analyze the following job posting.

Job Title:
{record.get("title", "")}

Company:
{record.get("company", "")}

Salary:
{record.get("salary", "")}

Job Description:
{record.get("description", "")}

Recruiter Message:
{record.get("recruiter_message", "")}

Evaluate whether the information provided is sufficient for analysis.

Return ONLY valid JSON using this structure:

{{
    "sufficient_data": true,
    "risk_level": "low",
    "risk_score": 0,
    "indicators": [],
    "explanation": ""
}}

Rules:
- sufficient_data must be true or false.
- risk_level must be "low", "medium", or "high".
- risk_score must be an integer from 0 to 100.
- indicators must be a list of strings.
- explanation must be a string.
"""

    return prompt.strip()


def call_api(prompt):
    """
    Send the prompt to the AI API.

    API implementation will be added later.
    Connection errors and timeouts should be caught here.
    """

    try:
        # TODO: Add AI API call here
        raw_response = ""

        return raw_response

    except TimeoutError:
        logger.error("AI API request timed out")
        return None

    except ConnectionError:
        logger.error("Could not connect to AI API")
        return None

    except Exception as error:
        logger.error("Unexpected AI API error: %s", error)
        return None


def parse_response(raw):
    """
    Extract JSON from the AI response.
    """

    if not raw:
        return None

    try:
        # First attempt: response is already pure JSON
        return json.loads(raw)

    except json.JSONDecodeError:

        # Try to extract JSON from surrounding text
        try:
            start = raw.find("{")
            end = raw.rfind("}")

            if start == -1 or end == -1:
                logger.error("No JSON object found in AI response")
                return None

            json_text = raw[start:end + 1]

            return json.loads(json_text)

        except (json.JSONDecodeError, TypeError):
            logger.error("Could not parse AI response as JSON")
            return None


def validate_response(data):
    """
    Validate the structure and values returned by the AI.
    """

    if not isinstance(data, dict):
        return False

    required_keys = [
        "sufficient_data",
        "risk_level",
        "risk_score",
        "indicators",
        "explanation"
    ]

    for key in required_keys:
        if key not in data:
            return False

    if not isinstance(data["sufficient_data"], bool):
        return False

    if data["risk_level"] not in ["low", "medium", "high"]:
        return False

    if not isinstance(data["risk_score"], int):
        return False

    if not 0 <= data["risk_score"] <= 100:
        return False

    if not isinstance(data["indicators"], list):
        return False

    if not all(isinstance(item, str) for item in data["indicators"]):
        return False

    if not isinstance(data["explanation"], str):
        return False

    return True


def analyze_job(record):
    """
    Main AI Manager pipeline.
    Every job record should pass through this function.
    """

    prompt = build_prompt(record)

    raw_response = call_api(prompt)

    if raw_response is None:
        return None

    data = parse_response(raw_response)

    if data is None:
        return None

    if not validate_response(data):
        logger.error("AI response failed validation")
        return None

    return data