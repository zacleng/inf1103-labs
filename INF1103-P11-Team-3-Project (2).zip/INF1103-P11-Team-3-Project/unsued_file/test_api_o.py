import os
from dotenv import load_dotenv
from google import genai

load_dotenv()
#load from .env file
client = genai.Client()
#Read the Gemini_API_key from the .env file.

response = client.models.generate_content(
    model = "gemini-3.8-flash",
    contents = "Hello Gemini! Confirm you are connect.",
)

print(response.text)