"""Job posting extraction: Gemini first, local Ollama fallback."""
import json
import os
import urllib.error
import urllib.request

from dotenv import load_dotenv

load_dotenv()


def _parse_object(text):
    if not text:
        raise ValueError("AI returned an empty response")
    result = json.loads(text)
    if not isinstance(result, dict):
        raise ValueError("AI returned JSON, but it was not an object")
    return result


def _gemini(prompt):
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-3-flash-preview"),
        contents=prompt,
        config=types.GenerateContentConfig(response_mime_type="application/json"),
    )
    return _parse_object(response.text)


def _ollama(prompt):
    base = os.getenv("OLLAMA_URL", "http://ollama:11434").rstrip("/")
    model = os.getenv("OLLAMA_MODEL", "qwen2.5:3b")
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0},
    }).encode("utf-8")
    request = urllib.request.Request(
        base + "/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=240) as response:
        body = json.load(response)
    return _parse_object(body.get("response"))


def call_api(prompt):
    if os.getenv("GEMINI_API_KEY", "").strip():
        try:
            return _gemini(prompt)
        except Exception as error:
            print(f"Gemini Autofill failed; trying Ollama: {error}", flush=True)
    else:
        print("GEMINI_API_KEY is not set; using Ollama for Autofill", flush=True)

    try:
        return _ollama(prompt)
    except Exception as error:
        print(f"Ollama Autofill failed: {error}", flush=True)
        raise RuntimeError("Both configured AI options failed to produce a JSON object") from error


def extract_job_posting(raw, metadata, options):
    prompt = (
        "You are an expert job scam detection assistant. Extract the following raw job posting into a JSON object "
        "matching the provided structure EXACTLY.\n\n"
        "Rules:\n"
        "1. Use only the allowed options for enum fields.\n"
        "2. Do not invent missing facts; use null for nullable fields if the data is not in the text.\n"
        "3. Identify potential scam indicators based on the text and list them in the 'detected_risks' array. "
        "Each risk requires: a valid 'category', a valid 'flag', a 'cite' (exact quote), and 'reasoning'.\n"
        "4. Return ONLY valid JSON matching the structure.\n\n"
        f"Required Structure (use this as your base):\n{json.dumps(metadata)}\n\n"
        f"Allowed Options:\n{json.dumps(options)}\n\n"
        f"Job posting raw text:\n{raw}"
    )
    return call_api(prompt)
