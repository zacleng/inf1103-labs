"""Pure, procedural decisions from the validated AI analysis contract."""

from copy import deepcopy
from validation_manager import (
    CATEGORIES, 
    CATEGORY_KEYS, 
    INDICATOR_ALIASES, 
    REPORT_FLAG_FACTORS,
    validate_detected_risks, FLAG_WEIGHTS, RISK_LEVELS, _validate_rules_against_registry
)



# Domain Brain: Multi-condition business rules
# Each tuple is (rule_name, forced_level, clauses)
# Every clause (tuple of factors) requires at least one factor to be True; all clauses must match.
RULES = (
    ("phishing_trap", "critical", (
        ("banking_information_request", "otp_or_password_request"),
        ("unverifiable_employer",)
    )),
    ("high_pay_low_barrier", "high", (
        ("unrealistic_salary", "no_experience_high_pay", "guaranteed_income"),
        ("excessive_urgency", "pressure_to_accept_immediately")
    )),
    ("financial_and_sensitive", "critical", (
        ("upfront_payment", "registration_or_training_fee", "equipment_purchase", "suspicious_payment_method"),
        ("otp_or_password_request", "banking_information_request", "unnecessary_identity_document")
    )),
    ("ghost_employer_fee_trap", "critical", (
        # Clause 1: The identity is missing or unverifiable (OR)
        ("missing_company_name", "unverifiable_employer", "limited_company_information"),
        # Clause 2: AND they are asking for money (OR)
        ("upfront_payment", "registration_or_training_fee", "suspicious_payment_method")
    ))
)
#validates rules on startup
_validate_rules_against_registry(RULES)

# INPUT: text (string).
# PROCESS: Ignores case, repeated whitespace, and removes one trailing full stop.
# OUTPUT: Returns a normalised string.
def _normalise_indicator(text):
    return " ".join(text.casefold().split()).removesuffix(".")

# INPUT: detected_risks (list of dicts).
# PROCESS: Maps precise report flags to internal boolean factors. Preserves all sources.
# OUTPUT: Returns a dictionary containing mapped risk_factors and lists of evidence/unresolved items.
def adapt_analysis(detected_risks):
    # Initialize empty factor mapping using the dynamic CATEGORIES
    factors = {category: dict.fromkeys(names, False) for category, names in CATEGORIES.items()}
    evidence, unresolved, context_items = {}, [], []
    
    # Flatten categories map for rapid lookup (maps internal_factor -> internal_category_key)
    categories_map = {factor: category for category, names in CATEGORIES.items() for factor in names}
    
    for index, source in enumerate(detected_risks):
        source = deepcopy(source)
        
        # Map directly using the precise report flag provided by the AI
        factor = REPORT_FLAG_FACTORS.get(source.get("flag"))
        category_key = CATEGORY_KEYS.get(source.get("category"))
        
        # If the flag doesn't exist in our SSOT registry
        if factor is None:
            unresolved.append({"index": index, **source, "reason": "unknown_evidence"})
            continue
            
        expected_category = categories_map.get(factor)
        
        # Verify the AI placed the flag in the correct category
        if category_key is not None and expected_category != category_key:
            unresolved.append({"index": index, **source, "reason": "category_mismatch"})
            continue
            
        # Successfully mapped finding
        factors[expected_category][factor] = True
        evidence.setdefault(factor, []).append(source)
            
    return {
        "risk_factors": factors, "factor_evidence": evidence,
        "unresolved_evidence": unresolved, "context_evidence": context_items,
        "source_items": deepcopy(detected_risks), "source_record": deepcopy(detected_risks),
        "input_format": "report_findings", "sufficient_data": None
    }




# INPUT: factors (dict)
# PROCESS: Flattens the nested category-based factors dictionary into a single flat dictionary of boolean flags.
# OUTPUT: Returns a flat dictionary mapping factor names to booleans.
def _flatten_factors(factors):
    flags = {}
    for category_flags in factors.values():
        flags.update(category_flags)
    return flags

# INPUT: flags (dict)
# PROCESS: Iterates over the dynamically loaded FLAG_WEIGHTS, adding the point value for every active flag.
# OUTPUT: Returns an integer representing the base score.
def _calculate_base_score(flags):
    return sum(FLAG_WEIGHTS.get(factor, 0) for factor, is_present in flags.items() if is_present)

# INPUT: value (int)
# PROCESS: Classifies a non-negative integer score using approved thresholds.
# OUTPUT: Returns the string risk level (Low, Medium, High, Critical).
def _score_level(value):
    if type(value) is not int or value < 0:
        raise ValueError("Score must be a non-negative integer.")
    return RISK_LEVELS[sum(value >= threshold for threshold in (20, 40, 70))]

# INPUT: flags (dict)
# PROCESS: Finds the highest minimum risk level enforced by matching RULES clauses.
# OUTPUT: Returns a string risk level or None if no rules match.
def _apply_rules(flags):
    matches = [level for _, level, clauses in RULES
               if all(any(flags.get(factor) for factor in clause) for clause in clauses)]
    return max(matches, key=RISK_LEVELS.index) if matches else None

# INPUT: detected_risks (list of dicts)
# PROCESS: Validates findings, calculates base score, applies overrides, and determines final level. Fails if inconclusive.
# OUTPUT: Returns a lowercase string risk level ('medium', 'high', 'critical'). Raises ValueError if inconclusive.
def calculate_risk_level(detected_risks):
    # 1. Validation Manager handles schema and duplicate checks
    validate_detected_risks(detected_risks)
    
    # 2. Map textual evidence to boolean flags using the risk schema adapter
    adapted = adapt_analysis(detected_risks)
    flags = _flatten_factors(adapted["risk_factors"])
    
    # 3. Calculate numeric score and baseline level using dynamic weights
    base_score = _calculate_base_score(flags)
    initial_level = _score_level(base_score)
    
    # 4. Apply domain brain rule overrides
    rule_level = _apply_rules(flags)
    final_level = max([initial_level] + ([rule_level] if rule_level else []), key=RISK_LEVELS.index)
    
    # 5. Enforce minimum evidence threshold
    # if final_level == "Low":
    #     raise ValueError("Risk assessment is inconclusive; provide recognised evidence before saving the report.")
        
    return final_level.lower()