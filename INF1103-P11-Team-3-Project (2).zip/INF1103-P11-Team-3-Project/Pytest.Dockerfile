FROM python:3.14.7-slim

# RUN apt-get update && apt-get install -y \
#     # build-essential \
#     # libsdl2-dev \
#     # libsdl2-image-dev \
#     # libsdl2-mixer-dev \
#     # libsdl2-ttf-dev \
#     # libfreetype6-dev \
#     # pkg-config \
#     && rm -rf /var/lib/apt/lists/*


WORKDIR /app

COPY . /app

RUN pip install --no-cache-dir -r requirements.txt

# COPY web.py .
# COPY templates ./templates

EXPOSE 5000
RUN touch tests.txt
RUN pytest -v validation/pytest_data_manager.py >> tests.txt
RUN pytest -v validation/pytest_logic_manager.py >> tests.txt

CMD ["cat", "tests.txt"]

