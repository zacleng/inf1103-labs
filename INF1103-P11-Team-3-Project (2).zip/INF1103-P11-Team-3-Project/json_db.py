import json
import os
import tempfile
from pathlib import Path
from validation_manager import validate_entry, validate_reports
from typing import Dict, Any

DEFAULT_JSON_PATH = Path(__file__).with_name("risk_evaluated_entry_samples.json")

# INPUT: None (No arguments required)
# PROCESS: Instantiates a standard dictionary matching the exact job entry JSON structure. Populates all fields with safe, default "empty" values (0, empty strings, empty lists, empty dicts, or None) using only primitive types.
# OUTPUT: Returns a strictly constructed dictionary representing a blank job posting record.
def create_empty_entry() -> Dict[str, Any]:
    # Construct and return the dictionary using primitive built-in types
    return {
        # Default integer identifiers to 0
        "entry_id": 0,
        "job_post_id": 0,
        
        # Default top-level strings to empty strings
        "platform": "",
        "raw_job_posting": "",
        
        # Default boolean flag to False
        "manual_entry": False,
        
        # Default datetime strings to empty strings
        "entry_created": "",
        "date_posted": "",
        
        # Initialize string lists as empty lists
        "job_type": [],
        "tasks": [],
        "benefits": [],
        
        # Explicitly set nullable fields to None
        "experience_level": None,
        "license": None,
        
        # Initialize nested location dictionary with its standard keys
        "location": {
            "type": "",
            "address": None
        },
        
        # Initialize nested contact dictionary with empty structures
        "contact": {
            "name": None,
            "methods": []
        },
        
        # Initialize complex nested data structures as empty dict/list
        "salary_scheme": {},
        "detected_risks": [],
        
        # Default top-level string to empty string
        "risk_level": ""
    }



# INPUT: path (string or Path object representing the file location)
# PROCESS: Safely opens the file and parses the JSON. Handles missing files by returning an empty list, and catches formatting/OS errors.
# OUTPUT: Returns the parsed JSON data (usually a list), or an empty list if the file doesn't exist. Raises ValueError on bad JSON.
def _read_raw(path):
    # Convert string path to a Path object for easier handling
    path = Path(path)
    try:
        # Open the file in read mode with UTF-8 encoding
        with path.open("r", encoding="utf-8") as f:
            # Parse the JSON content
            data = json.load(f)
    except FileNotFoundError:
        # If the database file does not exist yet, return an empty array
        return []
    except (OSError, json.JSONDecodeError) as exc:
        # If the file is inaccessible or contains invalid JSON, raise a descriptive error
        raise ValueError(f"Could not read valid JSON from {path}: {exc}") from exc
    # Return the successfully parsed raw data
    return data

# INPUT: path (string or Path object, defaults to DEFAULT_JSON_PATH)
# PROCESS: Reads the raw JSON data and passes it through the global report validation function.
# OUTPUT: Returns a list of completely validated and normalized report dictionaries.
def read_reports(path=DEFAULT_JSON_PATH):
    """Read and fully validate the JSON database."""
    # Read the raw data and immediately pass it to validate_reports
    return validate_reports(_read_raw(path))

# INPUT: path (string or Path target location), reports (list of validated report dictionaries)
# PROCESS: Writes data to a temporary file first, flushes it entirely to disk, and then atomically replaces the old file to prevent data corruption.
# OUTPUT: None (Writes to the filesystem)
def _atomic_write(path, reports):
    # Ensure path is a Path object
    path = Path(path)
    # Create the parent directory structure if it doesn't already exist
    path.parent.mkdir(parents=True, exist_ok=True)
    # Create a temporary file in the same directory to ensure they are on the same filesystem
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        # Open the file descriptor in write mode with UTF-8 encoding
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            # Dump the JSON data with formatting (indent=2) and ensure non-ASCII characters are kept
            json.dump(reports, f, ensure_ascii=False, indent=2, allow_nan=False)
            # Add a trailing newline for POSIX compliance
            f.write("\n")
            # Flush the internal Python buffer
            f.flush()
            # Force the OS to write the buffer to physical storage
            os.fsync(f.fileno())
        # Atomically replace the target file with the temporary file
        os.replace(temp_name, path)
    except Exception:
        try:
            # If any error occurs during writing, delete the temporary file to clean up
            os.unlink(temp_name)
        except OSError:
            pass
        # Re-raise the exception after cleanup
        raise

# INPUT: report (raw dictionary representing the new entry), path (string/Path object)
# PROCESS: Validates the new report, ensures the entry_id is unique across the existing database, appends it, and saves atomically.
# OUTPUT: Returns the validated, inserted report dictionary.
def create_report(report, path=DEFAULT_JSON_PATH):
    """Validate, insert a report with a unique entry_id, persist, and return it."""
    # Clean and validate the incoming report
    clean = validate_entry(report)
    # Load all existing reports
    reports = read_reports(path)
    # Check if the new entry_id already exists in the database
    if any(r["entry_id"] == clean["entry_id"] for r in reports):
        raise ValueError(f"Report with entry_id {clean['entry_id']} already exists")
    # Append the new clean report to the list
    reports.append(clean)
    # Persist the updated list atomically
    _atomic_write(path, reports)
    # Return the successfully added report
    return clean

# INPUT: entry_id (integer identifier), path (string/Path object)
# PROCESS: Searches through all validated reports to find the one matching the given entry_id.
# OUTPUT: Returns the matched report dictionary, or None if not found.
def get_report(entry_id, path=DEFAULT_JSON_PATH):
    # Iterate through all validated reports in the database
    for report in read_reports(path):
        # Check if the current report's ID matches the requested ID
        if report["entry_id"] == entry_id:
            # Return the first match immediately
            return report
    # Return None if the loop completes without finding a match
    return None

# INPUT: path (string/Path), filters (dict of filter conditions), sort_by (string field path), descending (boolean), limit (integer)
# PROCESS: Loads reports, filters them based on dynamic conditions (including nested fields), sorts the results, and applies a limit.
# OUTPUT: Returns a list of report dictionaries matching the criteria.
def list_reports(path=DEFAULT_JSON_PATH, filters=None, sort_by=None, descending=False, limit=None):
    """List reports; filters maps field paths to expected values or {op, value} conditions."""
    # Read the full dataset
    reports = read_reports(path)
    # Default filters to an empty dictionary if None is provided
    filters = filters or {}
    
    # Define a helper function to extract nested values using dot notation (e.g., "location.type")
    def value_at(report, dotted):
        value = report
        # Split the path and traverse the dictionary
        for part in dotted.split("."):
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                # Return None if the nested path is invalid
                return None
        return value

    # Map operator strings to their actual lambda functions
    ops = {
        "eq": lambda a, b: a == b, 
        "ne": lambda a, b: a != b,
        "gt": lambda a, b: a is not None and a > b,
        "gte": lambda a, b: a is not None and a >= b,
        "lt": lambda a, b: a is not None and a < b,
        "lte": lambda a, b: a is not None and a <= b,
        "contains": lambda a, b: b in a if a is not None else False,
        "in": lambda a, b: a in b,
    }
    
    # Iterate through all provided filter conditions
    for field, condition in filters.items():
        # Handle complex conditions structured as {"op": "operator", "value": "target"}
        if isinstance(condition, dict) and "op" in condition:
            op, expected = condition["op"], condition.get("value")
            if op not in ops:
                raise ValueError(f"Unsupported filter operator {op!r}")
        else:
            # Default to equality check if a raw value is provided
            op, expected = "eq", condition
        # Filter the reports list based on the resolved operator and expected value
        reports = [r for r in reports if ops[op](value_at(r, field), expected)]

    # Handle sorting if a sort_by field is provided
    if sort_by:
        # Sort using a tuple key: the first element groups None values at the end, the second performs the actual value sort
        reports.sort(key=lambda r: (value_at(r, sort_by) is None, value_at(r, sort_by)), reverse=descending)
        
    # Handle truncating the results if a limit is provided
    if limit is not None:
        # Validate that the limit is a valid non-negative integer
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
            raise ValueError("limit must be a non-negative integer or None")
        # Slice the list to the maximum limit length
        reports = reports[:limit]
        
    # Return the final filtered, sorted, and limited list
    return reports

# INPUT: entry_id (integer), updates (dictionary of fields to patch), path (string/Path)
# PROCESS: Locates a report, performs a deep recursive merge of the updates, completely validates the updated document, and writes it back.
# OUTPUT: Returns the validated, updated report dictionary.
def update_report(entry_id, updates, path=DEFAULT_JSON_PATH):
    """Merge updates recursively, validate the complete result, then atomically save."""
    # Ensure updates is a valid, non-empty dictionary
    if not isinstance(updates, dict) or not updates:
        raise ValueError("updates must be a non-empty dictionary")
        
    # Load all reports
    reports = read_reports(path)
    # Find the list index of the target report based on entry_id
    index = next((i for i, r in enumerate(reports) if r["entry_id"] == entry_id), None)
    # Raise an error if the report does not exist
    if index is None:
        raise ValueError(f"No report found with entry_id {entry_id}")

    # Define a helper function to deeply merge the nested update dictionary into the old report
    def merge(old, patch):
        for key, value in patch.items():
            # If both old and new values are dictionaries, recursively merge them
            if isinstance(old.get(key), dict) and isinstance(value, dict):
                merge(old[key], value)
            else:
                # Otherwise, overwrite or add the new value
                old[key] = value
                
    # Create a deep copy of the original report via JSON serialization to avoid side effects on failure
    candidate = json.loads(json.dumps(reports[index]))
    # Apply the recursive merge to the candidate copy
    merge(candidate, updates)
    
    # Strictly forbid modifying the primary key (entry_id)
    if candidate.get("entry_id") != entry_id:
        raise ValueError("entry_id cannot be changed by update_report")
        
    # Validate the fully merged candidate dictionary to ensure schema integrity
    clean = validate_entry(candidate)
    # Replace the old report in the array with the newly validated one
    reports[index] = clean
    # Save the updated database atomically
    _atomic_write(path, reports)
    # Return the clean, updated record
    return clean

# INPUT: entry_id (integer), path (string/Path)
# PROCESS: Locates a report by its ID, removes it from the dataset, and saves the updated list to disk.
# OUTPUT: Returns the deleted report dictionary, or None if it didn't exist.
def delete_report(entry_id, path=DEFAULT_JSON_PATH):
    """Delete by entry_id; return deleted report, or None if absent."""
    # Read the full dataset
    reports = read_reports(path)
    # Find the index of the report to delete
    index = next((i for i, r in enumerate(reports) if r["entry_id"] == entry_id), None)
    # If it isn't found, simply return None
    if index is None:
        return None
    # Remove the report from the list and store it in 'deleted'
    deleted = reports.pop(index)
    # Write the modified list back to disk
    _atomic_write(path, reports)
    # Return the report that was just deleted
    return deleted

# INPUT: path (string/Path)
# PROCESS: Loads and fully validates the database to verify overall file health and schema adherence.
# OUTPUT: Returns True if successful. (Raises an exception if validation fails).
def validate_database(path=DEFAULT_JSON_PATH):
    """Validate all reports in the file and return True if valid."""
    # Calling read_reports forces the full raw parsing and validate_reports routines
    read_reports(path)
    # If no exceptions were raised during read/validate, the database is intact
    return True
        