import json
import logging
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / '.env')

BASE_DIR = Path(__file__).resolve().parent
PROMPT_FILE = BASE_DIR / 'prompt.txt'
API_KEY = os.getenv('GEMINI_API_KEY')
API_BASE_URL = os.getenv('API_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta').rstrip('/')
API_MODEL = os.getenv('API_MODEL', 'gemini-3.6-flash')
OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://localhost:11434').rstrip('/')
OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'qwen2.5:14b')
LOGGER = logging.getLogger(__name__)


def build_prompt(job_data: dict) -> str:
    """Insert the job record and canonical risk categories into prompt.txt."""
    if not isinstance(job_data, dict):
        raise TypeError('job_data must be a dictionary')

    from validation_manager import RISK_FLAGS_BY_CATEGORY

    template = PROMPT_FILE.read_text(encoding='utf-8')
    schema = {category: sorted(flags) for category, flags in RISK_FLAGS_BY_CATEGORY.items()}
    job_json = json.dumps(job_data, ensure_ascii=False, indent=2, default=str)
    schema_json = json.dumps(schema, ensure_ascii=False, indent=2)

    # Use replace, not str.format: the prompt may contain literal JSON braces.
    replacements = {
        '{json.dumps(job_information, ensure_ascii=False, indent=2)}': job_json,
        '{schema}': schema_json,
        '{job_data}': job_json,
    }
    for placeholder, value in replacements.items():
        template = template.replace(placeholder, value)
    if not template.strip() or '{schema}' in template or '{job_data}' in template:
        raise ValueError('Prompt template is empty or has unresolved placeholders')
    return template


def _parse_and_validate(raw_response: str) -> list[dict]:
    """Parse AI JSON and validate with the project's canonical validator."""

    if not isinstance(raw_response, str) or not raw_response.strip():
        raise ValueError("AI returned an empty response")

    cleaned = raw_response.strip()

    # Remove Markdown code blocks if present
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines.pop()
        cleaned = "\n".join(lines).strip()

    # Convert JSON string into Python data
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError("AI returned invalid JSON") from exc

    # DEBUG: Check what Ollama actually returned
    print("AI PARSED RESPONSE:", repr(parsed), flush=True)

    # Handle JSON object containing detected_risks
    if isinstance(parsed, dict) and "detected_risks" in parsed:
        parsed = parsed["detected_risks"]

    # Validate the extracted risks
    from validation_manager import validate_detected_risks

    validated = validate_detected_risks(parsed)

    if not isinstance(validated, list):
        raise ValueError("Risk validator did not return a list")

    return validated


def _call_primary_api(prompt: str) -> list[dict]:
    """Call an OpenAI-compatible chat completions endpoint."""
    if not API_KEY:
        raise RuntimeError('Missing API_KEY or OPENAI_API_KEY')
    response = requests.post(
        f'{API_BASE_URL}/chat/completions',
        headers={'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'},
        json={
            'model': API_MODEL,
            'messages': [
                {'role': 'system', 'content': 'Analyze job scam risks. Return only a JSON array following the supplied schema.'},
                {'role': 'user', 'content': prompt},
            ],
            'temperature': 0,
        },
        timeout=(10, 180),
    )
    response.raise_for_status()
    payload = response.json()
    choices = payload.get('choices') or []
    if not choices:
        raise ValueError('Primary API response contained no choices')
    content = choices[0].get('message', {}).get('content')
    return _parse_and_validate(content)


def _call_ollama(prompt: str) -> list[dict]:
    """Call local Ollama and validate its response."""
    response = requests.post(
        f'{OLLAMA_URL}/api/chat',
        json={
            'model': OLLAMA_MODEL,
            'messages': [
                {'role': 'system', 'content': 'Analyze job scam risks. Return only a JSON array following the supplied schema.'},
                {'role': 'user', 'content': prompt},
            ],
            'format': 'json',
            'stream': True,  # Tell Ollama to stream the response
            'options': {'temperature': 0},
        },
        stream=True,  # Tell the requests library to stream the connection
        timeout=(10, 300),
    )
    response.raise_for_status()
    
    accumulated_content = parse_stream(response)
    
    # Join all chunks together and pass it to the validator
    content = "".join(accumulated_content)
    return _parse_and_validate(content)


def parse_stream(response):
    accumulated_content = []
        
    # Iterate through the streamed response chunks
    for line in response.iter_lines():
        if line:
            chunk_data = json.loads(line)
            content_chunk = chunk_data.get('message', {}).get('content', '')
            
            # Print the chunk to the terminal immediately without a newline
            # print(content_chunk, end='', flush=True)
            
            # Save the chunk to build the final complete string
            accumulated_content.append(content_chunk)
            
    # print()  # Print a final newline when the stream finishes
    return accumulated_content


def call_api(prompt: str) -> list[dict]:
    """Use the primary API; on any provider/response failure, try Ollama."""
    try:
        return _call_primary_api(prompt)
    except Exception as primary_error:
        LOGGER.warning('Primary AI failed; falling back to Ollama: %s', primary_error)
        try:
            return _call_ollama(prompt)
        except Exception as ollama_error:
            raise RuntimeError(
                f'Both AI services failed' # Primary: {primary_error}; Ollama: {ollama_error}'
            ) from ollama_error


def analyze_job(job_data: dict) -> list[dict]:
    """Return normalized detected risks, or raise an exception on failure."""
    return call_api(build_prompt(job_data))